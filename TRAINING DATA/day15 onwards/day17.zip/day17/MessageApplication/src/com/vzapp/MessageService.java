package com.vzapp;

public interface MessageService {
	public void sendMessage( String receiverName, String msg);
}
