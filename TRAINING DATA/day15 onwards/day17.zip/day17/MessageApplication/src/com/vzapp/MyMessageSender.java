package com.vzapp;

public class MyMessageSender {
	MessageService ms;

	public MessageService getMs() {
		return ms;
	}

	public void setMs(MessageService ms) {
		this.ms = ms;
	}
	
	

}
