package day12.q3.code;

public class ImaginaryRootsException extends RuntimeException {

	public ImaginaryRootsException() {
		super("The roots are Imaginary");
	}

}